# ticTacToeSite
It is a tic-tac-toe website created with html, css, and javascript
